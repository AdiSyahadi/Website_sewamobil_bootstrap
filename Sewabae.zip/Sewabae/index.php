<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- My Font -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

    <!-- Bagian CSS -->
    <link rel="stylesheet" href="style1b.css">

    <title>SewaAja</title>
  </head>
  <body>
<!-- Navbar -->

<nav class="navbar navbar-expand-lg navbar-light">
  <div class="container">
    <a class="navbar-brand" href="#">SewaAja</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav ml-auto">
        <a class="nav-item nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
        <a class="nav-item nav-link" href="#">About</a>
        <a class="nav-item btn btn-primary" href="#">Login Admin</a>
      </div>
    </div>
  </div>
</nav>
<!-- Akhir Navbar -->

<!-- Jumbotron -->
  <div class="jumbotron jumbotron-fluid">
    <div class="container">
      <h1 class="display-4">Profesional Rental Car Agency</h1>
      <p class="lead">Commitment to excellent service with premium safety standards and convenience that makes <br> it esy is our vision to provide customer satifacation</p>
      <a href="" class="btn btn-primary tombol">Get Started</a>
    </div>
  </div>
<!-- akhir jumbotron -->

<!-- coursel -->

<div class="container my-4">
  <!--Carousel Wrapper-->
  <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">

    <!--Controls-->
    <div class="controls-top">
      <a class="btn-floating" href="#multi-item-example" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
      <a class="btn-floating" href="#multi-item-example" data-slide="next"><i class="fa fa-chevron-right"></i></a>
    </div>
    <!--/.Controls-->

    <!--Indicators-->
    <ol class="carousel-indicators">
      <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
      <li data-target="#multi-item-example" data-slide-to="1"></li>
      <li data-target="#multi-item-example" data-slide-to="2"></li>
    </ol>
    <!--/.Indicators-->

    <!--Slides-->
    <div class="carousel-inner" role="listbox">
<!-- perulangan -->
  <?php
  include './login/config/dbconnection.php';

  $cek    = mysqli_query($con, "SELECT * FROM mobil ORDER BY id DESC limit 3");
  $response = array();
  $response["data"] = array();
  while ($x = mysqli_fetch_array($cek)) {
      array_push($response["data"], $x);
  }; ?>
      <!--First slide-->
      <div class="carousel-item active">

        <div class="row">
          <div class="col-md-4">
            <div class="card mb-2">
              <img class="card-img-top" src="<?= $response['data'][0]['url_foto_mobil']; ?>" alt="<?= $response['data'][0]['url_foto_mobil']; ?>"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;" >Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 clearfix d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(18).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 clearfix d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(35).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!--/.First slide-->

      <!--Second slide-->
      <div class="carousel-item">

        <div class="row">
          <div class="col-md-4">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(60).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 clearfix d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(47).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 clearfix d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/City/4-col/img%20(48).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!--/.Second slide-->

      <!--Third slide-->
      <div class="carousel-item">

        <div class="row">
          <div class="col-md-4">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/Food/4-col/img%20(53).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 clearfix d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/Food/4-col/img%20(45).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>

          <div class="col-md-4 clearfix d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/Food/4-col/img%20(51).jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title" style="color: black;">Card title</h4>
                <p class="card-text" style="color: black;">Some quick example text to build on the card title and make up the bulk of the
                  card's content.</p>
                <a class="btn btn-primary">Button</a>
              </div>
            </div>
          </div>
        </div>

      </div>
      <!--/.Third slide-->

    </div>
    <!--/.Slides-->

  </div>
  <!--/.Carousel Wrapper-->


</div>

<!-- Footer -->

<div class="container-fluid mx-auto">
  <div class="row justify-content-center top-part">
      <div class="col-md-6 text-center center-content">
          <div class="d-flex-inline">
              <h3 class="footer-heading">Start your journey with SewaAja</h3>
          </div>
          <div class="d-flex-inline">
              <p>We are based in Indonesia,Below you will find all the contact details you need.</p>
          </div>
          <div class="d-flex-inline pt-2"> <button class="btn-blue btn">GET STARTED</button> </div>
      </div>
  </div>
  <div class="row">
      <div class="line mb-3 mx-auto"></div>
      <div class="d-md-flex px-5 justify-content-around bd-highlight col-md-12 pt-5 pb-5 mb-3">
          <div class="p-2 flex-fill bd-highlight mb-5 mb-md-0">
              <h3>SewaAja</h3> <small>Copyright & copy 2021</small>
          </div>
          <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
              <h5 class="places">Our Office</h5>
              <p class="mb-0">Patra Jasa Office Tower</p>
              <p class="mb-0">Gedung Patra Jasa, Jl. Jend. Gatot Subroto,<br>Daerah Khusus Ibukota Jakarta 12950</p>
          </div>
          <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
              <h5 class="places">Follow us</h5>
              <img src="img/hires.png", style="width: 30px;">
              <img src="img/hires.png", style="width: 30px;">
              <img src="img/hires.png", style="width: 30px;">
          </div>
          <!-- <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0"> 
              <h5 class="places">WARSAW</h5>
              <p class="mb-0">Brain Embassy</p>
              <p class="mb-0">Alaya Jerasublisuble RS123</p>
              <p class="mb-0">02-222 Warsawa</p>
          </div>
          <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
              <h5 class="places">LONDON</h5>
              <p class="mb-0">Google Campus</p>
              <p class="mb-0">4-5 Barnhill, Shaneditch</p>
              <p class="mb-0">London EC2A 4BK</p>
          </div>
          <div class="p-2 flex-fill bd-highlight mb-3 mb-md-0">
              <h5 class="places">NORWAY</h5>
              <p class="mb-0">Kristiansand</p>
          </div>
      </div>
      <div class="line mb-3 mx-auto"></div>
  </div>
  <div class="row bottom-part">
      <div class="d-lg-flex justify-content-between bd-highlight col-md-12 mb-5 px-5">
          <div class="p-2 align-self-center flex-fill bd-highlight">
              <div class="fa fa-facebook px-2"> </div>
              <div class="fa fa-linkedin px-2"></div>
              <div class="fa fa-twitter px-2"></div>
              <div class="fa fa-instagram px-2"></div>
          </div>-->
          <div class="p-2 align-self-center flex-fill bd-highlight">
              <h5 class="places">Contact</h5>
              <div class="fa fa-mobile px-2 grey-text">&nbsp;&nbsp;<span id="contact">(021) 5290021</span></div>
              <div class="fa fa-envelope-o px-2 grey-text">&nbsp;&nbsp;info@par.co.id</div>
          </div>
      </div>
  </div>
</div>
<!-- akhir footer -->

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>